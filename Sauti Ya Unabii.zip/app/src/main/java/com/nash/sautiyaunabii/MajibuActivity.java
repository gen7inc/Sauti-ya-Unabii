package com.nash.sautiyaunabii;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MajibuActivity extends AppCompatActivity {
    public static final String MAJIBU_ID = "id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_majibu);
    }

}
