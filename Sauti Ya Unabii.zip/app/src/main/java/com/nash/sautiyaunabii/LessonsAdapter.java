package com.nash.sautiyaunabii;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

public class LessonsAdapter extends RecyclerView.Adapter<LessonsAdapter.ViewHolder> {

    private String[] titles;
    private String[] details;
    private int[] imageId;
    private Listener listener;

    //add the listener to the list fragment
    interface Listener {
        void onClick(int position);
    }

    //let's add the constructor
    public LessonsAdapter(String[] titles, String[] details, int[] imageId) {
        this.titles = titles; //holds the lesson title
        this.details = details; //holds the details
        this.imageId = imageId; //holds the image for a particular lesson
    }

    //also implement the getItemCount method
    @Override
    public int getItemCount() {
        return titles.length; //tell how long a list is
    }

    //activities and fragments will use this method to set as a listener
    public void setListener(Listener listener) {
        this.listener = listener;

    }

    //now the inner class for the viewHolder
    public static class ViewHolder extends RecyclerView.ViewHolder {
        //the viewHolder is used to hold the views (card view)
        private CardView cardView;

        public ViewHolder(CardView view){
            super(view);
            cardView = view;
        }

    }
    //now create the view holder
    @NonNull
    @Override
    public LessonsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        CardView cardView = (CardView) LayoutInflater.from(parent.getContext()).inflate(R.layout.my_card_view, parent, false);
        return new ViewHolder(cardView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        final CardView cardView = holder.cardView;
        //attach the image to the card
        ImageView imageView = cardView.findViewById(R.id.item_image);
        Drawable drawable = ContextCompat.getDrawable(cardView.getContext(), imageId[position]);
        imageView.setImageDrawable(drawable);

        //attach the title
        TextView textTitle = cardView.findViewById(R.id.item_title);
        textTitle.setText(titles[position]);

        //attach the details
        TextView textDetails = cardView.findViewById(R.id.item_detail);
        textDetails.setText(details[position]);

        //set the listener
        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(cardView.getContext(), LessonsDetailsActivity.class);
                intent.putExtra(LessonsDetailsActivity.EXTRA_LESSON_ID, position);
                cardView.getContext().startActivity(intent);

            }
        });

    }
}
