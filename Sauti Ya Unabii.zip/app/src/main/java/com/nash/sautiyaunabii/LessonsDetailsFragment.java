package com.nash.sautiyaunabii;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


/**
 * A simple {@link Fragment} subclass.
 */
public class LessonsDetailsFragment extends Fragment{
    private long lessonID; //this is the id of the lesson the user chooses

    public LessonsDetailsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_lessons_details, container, false);
    }

    @Override
    public void onStart() {
        super.onStart();
        View view = getView();
        if (view != null) {
            TextView lessonTitle = (TextView) view.findViewById(R.id.lesson_title);
            Lessons lessons = Lessons.lessons[(int) lessonID];
            lessonTitle.setText(lessons.getTitle()); //get the title

            TextView lessonDescription = (TextView) view.findViewById(R.id.lesson_description);
            lessonDescription.setText(lessons.getDescription());//get description

            TextView lessonContent = (TextView) view.findViewById(R.id.lesson_content);
            lessonContent.setText(lessons.getContent()); //get the content.

        }
    }


    public void setLesson(long id) {
        this.lessonID = id;
    }
}
