package com.nash.sautiyaunabii;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class LessonsListFragment extends Fragment {

    //add the listener to the list fragment
    interface Listener {
        void itemClicked(long id);
    }

    private Listener listener;

    //the list fragment
    public LessonsListFragment() {
        //requires empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        RecyclerView lessonRecycler = (RecyclerView)inflater.inflate(R.layout.fragment_lessons_list, container, false);

        //the title array
        String[] lessonTitles = new String[Lessons.lessons.length];
        for (int i = 0; i < lessonTitles.length; i++) {
            lessonTitles[i] = Lessons.lessons[i].getTitle(); //create array of titles
        }
        //the description array
        String[] lessonDescription = new String[Lessons.lessons.length];
        for (int i = 0; i < lessonDescription.length; i++) {
            lessonDescription[i] = Lessons.lessons[i].getDescription(); //create array of description
        }
        //the image resource
        int[] imageResource = new int[Lessons.lessons.length];
        for (int i = 0; i < imageResource.length; i++) {
            imageResource[i] = Lessons.lessons[i].getImageResourceId(); //create array of images
        }
        //now, get the adapter
        LessonsAdapter lessonsAdapter = new LessonsAdapter(lessonTitles, lessonDescription, imageResource);
        lessonRecycler.setAdapter(lessonsAdapter);
        //say how you want the views to be displayed
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        lessonRecycler.setLayoutManager(layoutManager);
        return lessonRecycler;

    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.listener = (Listener) context; //attach the listener to the activity when it gets attached to activity
    }

    /*@Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        if (listener != null) {
            listener.itemClicked(id);

        }
    }*/
}
