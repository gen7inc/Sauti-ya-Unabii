package com.nash.sautiyaunabii;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.ListFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * A simple {@link Fragment} subclass.
 */
public class QuestionsListFragment extends Fragment {

    //define the lister to listen for item clicks
    interface Listener {
        void onItemClicked(long id);
    }

    //register the listener
    private Listener questionsListener;

    //the constructor for the list fragment
    public QuestionsListFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        RecyclerView questionsRecycler = (RecyclerView)inflater.inflate(R.layout.fragment_questions_list, container, false);

        //first, get a list of question titles
        String[] questionsTitles = new String[Questions.questions.length];
        for (int i = 0; i < questionsTitles.length; i++) {
            questionsTitles[i] = Questions.questions[i].getMaswali_ya_somo_la(); //create array of titles

        }
        //then, the description array
        String[] questionsDescription = new String[Questions.questions.length];
        for (int i = 0; i < questionsDescription.length; i++) {
            questionsDescription[i] = Questions.questions[i].getKwanza(); //create array of titles

        }
        //now, attach the obtained question and its description to the adapter
        QuestionsAdapter questionsAdapter = new QuestionsAdapter(questionsTitles, questionsDescription);
        questionsRecycler.setAdapter(questionsAdapter); //set adapter to the recycler view

        //now, arrange the order in which the elements will be arranged
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        questionsRecycler.setLayoutManager(layoutManager);
        return questionsRecycler; //return the recycler
    }

    @Override
    public void onAttach(Context context) {
        //this method is called when list fragment gets attached to the activity
        super.onAttach(context);
        this.questionsListener = (Listener) context;
    }
    //respond to item clicks
    /*@Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        if (questionsListener != null) {
            questionsListener.onItemClicked(id);
        }
    }*/
}
