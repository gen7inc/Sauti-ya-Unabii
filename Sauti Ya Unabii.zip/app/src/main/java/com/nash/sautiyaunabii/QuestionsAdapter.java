package com.nash.sautiyaunabii;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class QuestionsAdapter extends RecyclerView.Adapter<QuestionsAdapter.ViewHolder> {
    private String[] questionTitles;
    private String[] questionDetails;
    private MyListener myListener;

    //add the listener to the list fragment
    interface MyListener {
        void onClick(int position);
    }


    //let's add the constructor
    public QuestionsAdapter(String[] titles, String[] details) {
        this.questionTitles = titles; //holds the lesson title
        this.questionDetails = details; //holds the details
    }

    //also implement the getItemCount method
    @Override
    public int getItemCount() {
        return questionTitles.length; //tell how long a list is
    }

    //activities and fragments will use this method to set as a listener
    public void setMyListener(MyListener myListener) {
        this.myListener = myListener;

    }
    //now the inner class for the viewHolder
    public static class ViewHolder extends RecyclerView.ViewHolder {
        //the viewHolder is used to hold the views (card view)
        private CardView cardView;

        public ViewHolder(CardView view) {
            super(view);
            cardView = view;
        }

    }

    //now create the view holder

    @NonNull
    @Override
    public QuestionsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        CardView cardView = (CardView) LayoutInflater.from(parent.getContext()).inflate(R.layout.my_questions_card_view, parent, false);
        return new QuestionsAdapter.ViewHolder(cardView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        final CardView cardView = holder.cardView;
        //attach the title
        TextView textTitle = cardView.findViewById(R.id.item_title);
        textTitle.setText(questionTitles[position]);

        //attach the details
        TextView textDetails = cardView.findViewById(R.id.item_detail);
        textDetails.setText(questionDetails[position]);

        //set the listener
        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(cardView.getContext(), QuestionsDetailsActivity.class);
                intent.putExtra(QuestionsDetailsActivity.EXTRA_QUESTION_ID, position);
                cardView.getContext().startActivity(intent);
            }
        });
    }

}
